<div class="page-title">Page Not Found</div>

<?php include_once (__ROOT__.'/includes/back-button.inc');?>

<table style="margin-left:auto; margin-right:auto;">
	<tr id="id-bad-page-tr">
		<td colspan="2" class="error-message">
			Validation Error: 404 - Page Not Found
		</td>
	</tr>
</table>